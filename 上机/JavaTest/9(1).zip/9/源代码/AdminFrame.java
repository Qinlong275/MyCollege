package test6;

import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JTextField;
import javax.swing.border.EmptyBorder;

public class AdminFrame extends JFrame{

	private static final long serialVersionUID = 1L;
	private JPanel contentPane;
	private JPasswordField passwordField;
	private JTextField textField;
	
	public AdminFrame(){
		CreateFrame();
	}
	
	private void CreateFrame(){
		
		setTitle("���ι滮���񡪡���¼����");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 450, 300);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel u_label = new JLabel("�û�������ʼΪ�գ�:");
		u_label.setBounds(30, 100, 204, 15);
		contentPane.add(u_label);
		
		JLabel p_label = new JLabel(" ���루��ʼΪ�գ� :");
		p_label.setBounds(30, 162, 204, 15);
		contentPane.add(p_label);
		
		//�û�����
		textField = new JTextField();
		textField.setBounds(172, 97, 156, 20);
		contentPane.add(textField);
		textField.setColumns(10);
		
		//�����
		passwordField = new JPasswordField();
		passwordField.setBounds(172, 159, 156, 20);
		contentPane.add(passwordField);
		
		//ȷ�Ͽ�
		JButton button_confirm = new JButton("ȷ��");
		button_confirm.setBounds(116, 206, 78, 23);
		contentPane.add(button_confirm);
		
		button_confirm.addMouseListener(new MouseAdapter(){
			@Override
			public void mouseClicked(MouseEvent e){
			String u_name = textField.getText();
			String password = new String(passwordField.getPassword());
			
		    Admin admin  =  new Admin("","");//�����û���
			if(u_name.equals(admin.getName()) && password.equals(admin.getPassword()) ){
			                   ManagerFrame m_frame = new ManagerFrame();
			                   m_frame.setVisible(true);
			                   setVisible(false);
		     }
			else{
				JOptionPane.showMessageDialog(null,"�û������������","��ʾ",JOptionPane.WARNING_MESSAGE);
			}
		}});
		
		//���ؿ�
		JButton button_back = new JButton("����");
		button_back.setBounds(225, 206, 78, 23);
		contentPane.add(button_back);
		
		button_back.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e){
				FirstFrame i_frame = new FirstFrame();
				i_frame.setVisible(true);
				setVisible(false);
			}
		});
	}	
}