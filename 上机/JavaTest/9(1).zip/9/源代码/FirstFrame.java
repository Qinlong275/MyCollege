package test6;

import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

public class FirstFrame extends JFrame {//��ʼ����
            
	      private static final long serialVersionUID = 1L;
	      
          private JPanel contentPane;
	      public FirstFrame(){
	    	  CreateFrame();
	      }  
	      
	     private void CreateFrame(){
	    	       
	    	        setTitle("���ι滮����");
	    			setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	    			setBounds(100, 100, 450, 300);
	    		
	    			contentPane = new JPanel();
	    			contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
	    			setContentPane(contentPane);	    			
	    			contentPane.setLayout(null);
	    			
	    			
	    			JButton button_visitor = new JButton("�ο�ģʽ");
	    			button_visitor.setBounds(174, 55, 93, 23);
	    			contentPane.add(button_visitor);
	    			button_visitor.addMouseListener(new MouseAdapter() {
						@Override
						public void mouseClicked(MouseEvent e) {
							VisitFrame u_frame = new VisitFrame(0);
							u_frame.setVisible(true);
							setVisible(false);
						}
					});
	    			
	    			JButton button_manager = new JButton("����ģʽ");
	    			button_manager.setBounds(174, 139, 93, 23);
	    			contentPane.add(button_manager);
	    			
	    			button_manager.addMouseListener(new MouseAdapter() {
	    				@Override
	    				public void mouseClicked(MouseEvent e) {
	    					AdminFrame a_frame = new AdminFrame();
	    					a_frame.setVisible(true);
	    					setVisible(false);
	    				}
	    			});
	     }
}
