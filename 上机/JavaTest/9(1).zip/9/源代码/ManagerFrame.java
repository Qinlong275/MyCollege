package test6;

import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.util.ArrayList;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextField;
import javax.swing.border.EmptyBorder;

public class ManagerFrame extends JFrame{

	private static final long serialVersionUID = 1L;
             
	private JPanel contentPane;
	private JTextField name_textField;
	private JTextField content_textField;
	private JTextField hotel_textField;
	private JTextField vehicle_textField;
	private JTextField guide_textField;
	private JTextField duration_textField;
	private JTextField price_textField;

	static ArrayList<Visitor> t = new ArrayList<Visitor>();//���������ArrayList
		
	public ManagerFrame(){
		CreateFrame();
	}
	
	private void CreateFrame(){
		setTitle("���ι滮���񡪡��趨����");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 487, 420);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		//��������
		JLabel  name_label = new JLabel("������:");
		name_label.setBounds(30, 154, 54, 15);
		contentPane.add(name_label);
		//�������ƿ�
		name_textField = new JTextField();
		name_textField.setBounds(94, 151, 101, 21);
		contentPane.add(name_textField);
		name_textField.setColumns(10);		
		
		//��������
		JLabel content_label = new JLabel("��������:");
		content_label.setBounds(260, 34, 60, 15);
		contentPane.add(content_label);
		//���ù������
		JScrollPane content_scrollPane = new JScrollPane();
		content_scrollPane.setBounds(317, 25, 144, 25);
		contentPane.add(content_scrollPane);
		//�������ݿ�
		content_textField = new JTextField();
		content_scrollPane.setViewportView(content_textField);
		content_textField.setColumns(10);
		
		//��ͨ����
		JLabel hotel_label = new JLabel("��ͨ����:");
		hotel_label.setBounds(260, 75, 60, 15);
		contentPane.add(hotel_label);
		//���ù������
		JScrollPane hotel_scrollPane = new JScrollPane();
		hotel_scrollPane.setBounds(317, 68, 144, 25);
		contentPane.add(hotel_scrollPane);
		//��ͨ���߿�
		hotel_textField = new JTextField();
		hotel_scrollPane.setViewportView(hotel_textField);
		hotel_textField.setColumns(10);
		
		//ס��
		JLabel vehicle_label = new JLabel("ס��:");
		vehicle_label.setBounds(260, 120, 54, 15);
		contentPane.add(vehicle_label);
		//���ù������
		JScrollPane vehicle_scrollPane = new JScrollPane();
		vehicle_scrollPane.setBounds(317, 115, 144, 25);
		contentPane.add(vehicle_scrollPane);
		//ס�޿�
		vehicle_textField = new JTextField();
		vehicle_scrollPane.setViewportView(vehicle_textField);
		vehicle_textField.setColumns(10);
		
		//����
		JLabel guide_label = new JLabel("����:");
		guide_label.setBounds(260, 170, 54, 15);
		contentPane.add(guide_label);
		//���ù������
		JScrollPane guide_scrollPane = new JScrollPane();
		guide_scrollPane.setBounds(317, 165, 144, 25);
		contentPane.add(guide_scrollPane);
		//���ο�
		guide_textField = new JTextField();
		guide_scrollPane.setViewportView(guide_textField);
		guide_textField.setColumns(10);

		//ʱ��
		JLabel duration_label = new JLabel("ʱ��:");
		duration_label.setBounds(260, 225, 54, 15);
		contentPane.add(duration_label);
		//ʱ����
		duration_textField = new JTextField();
		duration_textField.setBounds(317, 220, 144, 25);
		contentPane.add(duration_textField);
		duration_textField.setColumns(10);
		
		//�۸�
		JLabel price_label = new JLabel("�۸�:");
		price_label.setBounds(260, 271, 60, 15);
		contentPane.add(price_label);
		//�۸��
		price_textField = new JTextField();
		price_textField.setBounds(317, 265, 144, 25);
		contentPane.add(price_textField);
		price_textField.setColumns(10);
		
		//ȷ�Ͽ�
		JButton confirm_Button = new JButton("ȷ��");
		confirm_Button.setBounds(265, 330, 93, 23);
		contentPane.add(confirm_Button);
		confirm_Button.addMouseListener(new MouseAdapter() {		
			@Override
			public void mouseClicked(MouseEvent e) {
				String name = name_textField.getText();
				String []content = content_textField.getText().split(" ");
				String []vehicle = vehicle_textField.getText().split(" ");
				String []hotel = hotel_textField.getText().split(" ");
				String []guide = guide_textField.getText().split(" ");
				String duration = duration_textField.getText();
				String price = price_textField.getText();
				
				Visitor tourist = new Visitor();				
				t.add(tourist);
				for(int i=0;i<t.size();i++){
					if(t.get(i).getName() == null || t.get(i).getName().equals(name)){
						System.out.println(i);
						t.get(i).setContent(content);
						t.get(i).setVehicle(vehicle);
						t.get(i).setHotel(hotel);
						t.get(i).setGuide(guide);
						t.get(i).setDuration(duration);
						t.get(i).setPrice(price);
						if( i == (t.size() - 1))	t.get(i).setName(name);
						else t.remove(t.size() - 1);
					}
				}
				JOptionPane.showMessageDialog(null,"���ӳɹ�","��ʾ",JOptionPane.INFORMATION_MESSAGE);
			}
		});
		
		//���ؿ�
		JButton back_Button = new JButton("����");
		back_Button.setBounds(368,330,93,23);
		contentPane.add(back_Button);
		back_Button.addMouseListener(new MouseAdapter() {		
			@Override
			public void mouseClicked(MouseEvent e) {
				// TODO Auto-generated method stub
				FirstFrame i_frame = new FirstFrame();
				i_frame.setVisible(true);
				setVisible(false);
			}
		});
	}
}