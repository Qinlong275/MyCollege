package test6;

import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.util.ArrayList;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.border.EmptyBorder;

public class VisitFrame extends JFrame{

	private static final long serialVersionUID = 1L;
	private JPanel contentPane;
	ArrayList<Visitor> t = ManagerFrame.t;
	int i;
	public VisitFrame(int num){
    	CreateFrame(num);
    }
	
    private void CreateFrame(int num){//����ΪWindows builder
    	i = num;       	
    	setTitle("���ι滮���񡪡��οͽ���");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 450, 420);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		//��������
		JLabel name_label = new JLabel();
		name_label.setText(ManagerFrame.t.get(i).getName());
		name_label.setBounds(206, 31, 54, 15);
		contentPane.add(name_label);		
		//�л�����һ��
		JButton next_Button = new JButton(">");
		next_Button.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
					System.out.println(i);
				     i = (i+1)%t.size();
					VisitFrame u_frame = new VisitFrame(i);
					u_frame.setVisible(true);
					setVisible(false);
			}
		});
		next_Button.setBounds(314, 27, 50, 23);
		contentPane.add(next_Button);		
		//�л�����һ��
		JButton previous_Button = new JButton("<");
		previous_Button.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				    if(i == 0) i = t.size() -1;
				    else i = (i-1)%t.size();
					VisitFrame u_frame = new VisitFrame(i);
					u_frame.setVisible(true);
					setVisible(false);
			}
		});
		previous_Button.setBounds(99, 27, 50, 23);
		contentPane.add(previous_Button);

		//��������
		JLabel content_label = new JLabel("��������:");
		content_label.setBounds(147, 83, 60, 15);
		contentPane.add(content_label);
		//��������		
		JComboBox content_comboBox = new JComboBox(getData(ManagerFrame.t.get(i).getContent()));
		content_comboBox.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
			}
		});
		content_comboBox.setBounds(229, 80, 80, 21);
		contentPane.add(content_comboBox);
				
		//��ͨ����
		JLabel hotel_label = new JLabel("��ͨ����:");
		hotel_label.setBounds(147, 123, 60, 15);
		contentPane.add(hotel_label);
		//��������
		JComboBox hotel_comboBox = new JComboBox(getData(ManagerFrame.t.get(i).getHotel()));
		hotel_comboBox.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
			}
		});
		hotel_comboBox.setBounds(229, 120, 80, 21);
		contentPane.add(hotel_comboBox);
		
		//ס��
		JLabel vehicle_label = new JLabel("ס��:");
		vehicle_label.setBounds(147, 163, 54, 15);
		contentPane.add(vehicle_label);
		//��������
		JComboBox vehicle_comboBox = new JComboBox(getData(ManagerFrame.t.get(i).getVehicle()));
		vehicle_comboBox.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
			}
		});
		vehicle_comboBox.setBounds(229, 160, 80, 21);
		contentPane.add(vehicle_comboBox);
		
		//����
		JLabel guide_label = new JLabel("����:");
		guide_label.setBounds(147, 203, 54, 15);
		contentPane.add(guide_label);
		//��������
		JComboBox guide_comboBox = new JComboBox(getData(ManagerFrame.t.get(i).getGuide()));
		guide_comboBox.setBounds(229, 200, 80, 21);
		contentPane.add(guide_comboBox);
		
		//ʱ��
		JLabel duration_label = new JLabel("ʱ��:");
		duration_label.setBounds(147, 250, 54, 15);
		contentPane.add(duration_label);
		//ʱ����
		JTextField duration_textField = new JTextField();
		duration_textField.setBounds(214, 247, 100, 21);
		duration_textField.setText(ManagerFrame.t.get(i).getDuration());
		contentPane.add(duration_textField);
		duration_textField.setColumns(10);
		duration_textField.setEditable(false);
		
		//�۸�
		JLabel price_label = new JLabel("�۸�:");
		price_label.setBounds(147, 284, 60, 15);
		contentPane.add(price_label);
		//�۸��
		JTextField price_textField = new JTextField();
		price_textField.setBounds(214, 281, 100, 21);
		price_textField.setText(ManagerFrame.t.get(i).getPrice());
		contentPane.add(price_textField);
		price_textField.setColumns(10);
		price_textField.setEditable(false);
		
		//���ذ�ť
		JButton back_button = new JButton("����");
		back_button.setBounds(178, 335, 93, 23);
		contentPane.add(back_button);
		
		back_button.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				FirstFrame i_frame = new FirstFrame();
				i_frame.setVisible(true);
				setVisible(false);
			}
		});
	}
    private String[] getData(ArrayList<String> data){
	     String [] str= new String[data.size()];
	     for(int i=0;i<str.length;i++) str[i] = data.get(i);
	     return str;
    }
}